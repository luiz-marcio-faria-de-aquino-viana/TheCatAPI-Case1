#!/bin/sh
THECATAPICASE1_HOME=/home/lmarcio/TheCatAPICase1/
export THECATAPICASE1_HOME

DATADIR=$THECATAPICASE1_HOME/Data

# SAMPLE DATABASE DELETE
rm -f $DATADIR/*dat
rm -f $DATADIR/Images/*jpg
rm -f $DATADIR/Images/*png
rm -f $DATADIR/CatsWithHat/*jpg
rm -f $DATADIR/CatsWithHat/*png
rm -f $DATADIR/CatsWithGlasses/*jpg
rm -f $DATADIR/CatsWithGlasses/*png

